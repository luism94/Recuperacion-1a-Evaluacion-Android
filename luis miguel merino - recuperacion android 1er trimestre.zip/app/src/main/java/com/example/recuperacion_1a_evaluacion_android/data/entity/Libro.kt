package com.example.recuperacion_1a_evaluacion_android.data.entity

import android.os.Parcelable
import android.widget.ImageView
import kotlinx.parcelize.Parcelize

@Parcelize
data class Libro(val idLibro: Int, val titulo: String, val autor: String, val anio: Int, val urlPortada: String): Parcelable