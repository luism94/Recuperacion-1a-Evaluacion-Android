package com.example.recuperacion_1a_evaluacion_android


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.recuperacion_1a_evaluacion_android.data.entity.Libro
import com.example.recuperacion_1a_evaluacion_android.databinding.MainActivityBookBinding


class MainActivityAdapter(): androidx.recyclerview.widget.ListAdapter<Libro, MainActivityAdapter.ViewHolder>(CallbackDiferenciasLibros) {

    private var onItemClickListener: ((Int) -> Unit)? = null

    fun setOnItemClickListener(onItemClickListener: ((Int) -> Unit)?) {
        this.onItemClickListener = onItemClickListener
    }

    var listaLibros: List<Libro> = emptyList()

    inner class ViewHolder(private var binding: MainActivityBookBinding): RecyclerView.ViewHolder(binding.root) {
        init {
            itemView.setOnClickListener {
                val position = absoluteAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClickListener?.invoke(position)
                }
            }
        }

        fun bind(libro: Libro) {
            binding.bookTitle.text = libro.titulo
            binding.bookAuthor.text = libro.autor
            binding.bookYear.text = libro.anio.toString()
            //Glide.with(this@MainActivityAdapter).load(binding.titlePageBook)    //Recibir contexto de MainActivity de alguna forma
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MainActivityAdapter.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = MainActivityBookBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewholder: MainActivityAdapter.ViewHolder, posicion: Int) {
        viewholder.bind(currentList[posicion])
    }
}


object CallbackDiferenciasLibros: DiffUtil.ItemCallback<Libro>() {
    override fun areItemsTheSame(libroAnterior: Libro, libroNuevo: Libro): Boolean {
        return libroAnterior.idLibro == libroNuevo.idLibro
    }

    override fun areContentsTheSame(libroAnterior: Libro, libroNuevo: Libro): Boolean {
        return libroAnterior.idLibro == libroNuevo.idLibro &&
                libroAnterior.titulo == libroNuevo.titulo &&
                libroAnterior.autor == libroNuevo.autor &&
                libroAnterior.anio == libroNuevo.anio
    }
}