package com.example.recuperacion_1a_evaluacion_android.data

import androidx.lifecycle.LiveData
import com.example.recuperacion_1a_evaluacion_android.data.entity.Libro

interface DataSource {
    //Para recibir la lista guardada de libros del viewModel
    fun recibirLiveDataLibros(): LiveData<List<Libro>>

    //Crear un libro y guardarlo en la lista
    fun aniadirLibro(titulo: String, autor: String, fecha: Int, urlPortada: String)

    //Eliminar libro con gesto swipe
    fun eliminarLibro(idLibro: Int)
}