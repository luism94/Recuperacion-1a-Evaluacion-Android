package com.example.recuperacion_1a_evaluacion_android

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.recuperacion_1a_evaluacion_android.data.Database
import com.example.recuperacion_1a_evaluacion_android.data.entity.Libro

class MainActivityViewModel(val baseDatos: Database): ViewModel() {
    var mostrarPanel: MutableLiveData<Boolean> = MutableLiveData()
    var listaLibros: LiveData<List<Libro>> = baseDatos.recibirLiveDataLibros()

    fun toggleBookPanel() {
        mostrarPanel.value = !mostrarPanel.value!!
    }

    fun eliminarLibro(posicion: Int) {
        if (listaLibros.value != null) {
            baseDatos.eliminarLibro(listaLibros.value!!.elementAt(posicion).idLibro)
        } else {
            //Mostrar snackbar
        }
    }
}