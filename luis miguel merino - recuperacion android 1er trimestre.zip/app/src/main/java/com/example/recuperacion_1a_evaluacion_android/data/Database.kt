package com.example.recuperacion_1a_evaluacion_android.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.recuperacion_1a_evaluacion_android.data.entity.Libro

object Database : DataSource {
    //Inicializo la lista mutable de libros con una lista vacia
    private var listaLibros: MutableList<Libro> = mutableListOf()
    //Inicializo LiveData con la lista de libros
    private var liveDataLibros: MutableLiveData<List<Libro>> = MutableLiveData(listaLibros)

    private var idLibroInicial: Int = 0

    override fun recibirLiveDataLibros(): LiveData<List<Libro>> {
        listaLibros.toList().sortedBy { it.idLibro }
        liveDataLibros.value = ArrayList<Libro>(listaLibros)
        return liveDataLibros
    }

    override fun aniadirLibro(titulo: String, autor: String, fecha: Int, url: String) {
        idLibroInicial++
        listaLibros.add(Libro(idLibroInicial, titulo, autor, fecha, url))
    }

    override fun eliminarLibro(idLibro: Int) {
        val eliminado: Boolean = false
        for (libro: Libro in listaLibros) {
            if (libro.idLibro  == idLibro) {
                listaLibros.remove(libro)
            }
        }
        //Actualizo la lista de libros cuando se elimina un libro
        if (eliminado) {
            liveDataLibros.value = ArrayList(listaLibros)
        }
    }
}