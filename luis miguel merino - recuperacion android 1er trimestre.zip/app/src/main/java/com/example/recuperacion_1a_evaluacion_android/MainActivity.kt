package com.example.recuperacion_1a_evaluacion_android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recuperacion_1a_evaluacion_android.data.Database
import com.example.recuperacion_1a_evaluacion_android.databinding.MainActivityBinding
import utils.setOnSwipeListener


class MainActivity : AppCompatActivity() {
    private lateinit var binding: MainActivityBinding

    private val mainActivityViewModel: MainActivityViewModel by viewModels {
        MainActivityViewModelFactory(Database)
    }

    private val adaptadorListaLibros: MainActivityAdapter = MainActivityAdapter().apply {
        setOnItemClickListener {
                position -> mainActivityViewModel.toggleBookPanel()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = MainActivityBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setupViews()

    }

    private fun setupViews() {
        binding.bookPanel.isVisible = false
        setupAdaptadorLista()
    }

    private fun setupAdaptadorLista() {
        binding.bookList.apply {
            setHasFixedSize(true)
            adapter = adaptadorListaLibros
            addItemDecoration(DividerItemDecoration(this@MainActivity, RecyclerView.VERTICAL))
            itemAnimator = DefaultItemAnimator()
            layoutManager = LinearLayoutManager(this@MainActivity)
            setOnSwipeListener { viewHolder, _ -> adaptadorListaLibros.currentList[viewHolder.absoluteAdapterPosition]}
        }
    }

}